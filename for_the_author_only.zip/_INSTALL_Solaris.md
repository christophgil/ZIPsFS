# Install ZIPsFS on Solaris, Illumos, Smartos

(Only tested for Smartos)

https://github.com/myaut/solaris-sparc-fuse
pkgin
