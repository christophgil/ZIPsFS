# Install ZIPsFS on Debian or Ubuntu

    apt-get update
    apt-get install fuse-zip   libfuse3-dev  libzip-dev build-essential unzip lynx tmux

_SNIPPET_INSTALL

# TroubleShooting


_SNIPPET_fuse-zip
