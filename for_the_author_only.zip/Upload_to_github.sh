#!/usr/bin/env bash
set -u
DIR="${BASH_SOURCE[0]}"
DIR=${DIR%/*}
MD=$DIR/ZIPsFS.1.md
MAN=$DIR/ZIPsFS.1


make_man(){
    chmod +w $MAN
    {
        cat <<EOF
% ZIPsFS(1)

NAME
====

**ZIPsFS** - FUSE-based  overlay union file system expanding ZIP files
EOF
        cat $MD
    }| pandoc  -s -t man >$MAN
    chmod -w $MAN
}



# ./INSTALL.md ./ZIPsFS_configuration.md ./ZIPsFS_generated_files.md ./ZIPsFS_cache.md ZIPsFS_logs.md ZIPsFS_fault_management.md


collapsed(){
    echo "<details><summary>$1</summary>"
    cat $2 || exit 1
    echo "</details>"
}

make_readme(){
    echo '# ZIPsFS - FUSE-based  overlay file system which expands  ZIP files'
    echo
    echo
    cat $MD
    echo
    echo ' - [Installation](./INSTALL.md)'
    collapsed 'Configuration'   'ZIPsFS_configuration.md'
    collapsed 'Generated (synthetic) files: Automatic file conversions, Accessing web resources as regular files'   'ZIPsFS_generated_files.md'
    collapsed 'Logging'   'ZIPsFS_logs.md'
    collapsed 'Fault management. Timouts for remote upstream file systems. Duplicated remote trees'   'ZIPsFS_fault_management.md'
    collapsed 'Improve performance  caching file content and meta data'   'ZIPsFS_cache.md'
    collapsed 'Use-case - application for high-throughput mass-spectrometry'   'USE_CASE.md'
    collapsed 'Implementation'  ZIPsFS_implementation.md
    collapsed 'Limitations and Bugs'   'ZIPsFS_Limitations.md'
    collapsed 'See also related sites'   'ZIPsFS_related_sites.md'
    echo

}
make_use_case(){
    cat <<EOF
# Use case - Archive of mass spectrometry files


We use closed-source proprietary Windows software to read large experimental data from various types
of mass spectrometry machines. The data is immediatly copied into an intermediate storage on the processing PC and
eventually archived in a read-only WORM file
system.

To reduce the number of individual files and disk usage and to allow for data integrity checks, all files from a single mass spectrometry
measurement are bundled into one ZIP archive. With fewer individual files, searching through the
entire directory hierarchy takes less than 1 hour.

We initially hoped that files inside ZIP archives would be  accessed using

 - Pipes
 - Named pipes
 - Process substitution
 - FUSE file systems with which transparently expand multiple ZIP files
 - Unzipping and storing  extracted files on disk

Unfortunately, these techniques did not work for our use case. Mounting individual ZIP files was initially the only solution. But when sample size
of large experiments got large, even this was not feasable.

ZIPsFS was developed to solve the following problems:

- **Growing Number of ZIP Files**: Recently, the size of our experiments - and therefore the number of ZIP files - has increased enormously. Mounting thousands of individual ZIP files results in a very long <i>/etc/mtab</i> file and puts a significant strain on the operating system.

- **Write Access Requirements**: Some proprietary software requires write access to both files and their parent directories.

- **Inefficiency in Random File Access**: Some mass spectrometry files are read from varying positions. Random access  is particularly inefficient for compressed ZIP entries, in particular with backward seeks. Buffering of file content is required.

- **Multiple Storage Locations**: Experimental records are initially stored in an intermediate storage location and, after verification, are moved to the final archive. Consequently, we need a union file system.

- **Resilience of storage systems:** Sometimes access to the archive gets blocked. Otherwise there are several alternative entry points which will continue to work. This adds requirement for
fault management.

- **Redundant File System Requests**: Some proprietary software generates millions of redundant requests to the file system, which is problematic for both remote files and mounted ZIP files.
File attributes need to be cached.


<SPAN>



 <DIV style="padding:1em;border:2px solid gray;float:left;">
       File tree with zip files on hard disk:
 <BR>
       <PRE style="font-family: monospace,courier,ariel,sans-serif;">
 ├── <B style="color:#1111FF;">src</B>
 │   ├── <B style="color:#1111FF;">InstallablePrograms</B>
 │   │   └── some_software.zip
 │   │   └── my_manuscript.zip
 └── <B style="color:#1111FF;">read-write</B>
    ├── my_manuscript.zip.Content
            ├── my-modified-text.txt
       </PRE>
 </div>

 <DIV style="padding:1em;border:2px solid gray;float:right;">
       Virtual file tree presented by ZIPsFS:
       <PRE style="font-family: monospace,courier,ariel,sans-serif;">
 ├── <B style="color:#1111FF;">InstallablePrograms</B>
 │   ├── some_software.zip
 │   └── <B style="color:#1111FF;">some_software.zip.Content</B>
 │       ├── help.html
 │       ├── program.dll
 │       └── program.exe
 │   ├── my_manuscript.zip
 │   └── <B style="color:#1111FF;">my_manuscript.zip.Content</B>
 │       ├── my_text.tex
 │       ├── my_lit.bib
 │       ├── fig1.png
 │       └── fig2.png
       </PRE>
 </DIV>

 <DIV style="clear:both;">
     The file tree can be adapted to specific needs by editing <I>ZIPsFS_configuration.c</I>.
     Our mass-spectrometry files are processed with special software.
     It expects a file tree in its original form i.e. as files would not have been zipped.
     Furthermore, write permission is required for files and containing folders while files are permanently stored and cannot be modified any more.
     The folder names need to be ".d" instead of ".d.Zip.Content".
     For Sciex (zenotof) machines, all files must be in one folder without intermediate folders.
 </DIV>

 <DIV style="padding:1em;border:2px solid gray;float:left;">
                     File tree with zip files on our NAS server:
       <PRE style="font-family: monospace,courier,ariel,sans-serif;">
 ├── <B style="color:#1111FF;">brukertimstof</B>
 │   └── <B style="color:#1111FF;">202302</B>
 │       ├── 20230209_hsapiens_Sample_001.d.Zip
 │       ├── 20230209_hsapiens_Sample_002.d.Zip
 │       └── 20230209_hsapiens_Sample_003.d.Zip

 ...

 │       └── 20230209_hsapiens_Sample_099.d.Zip
 └── <B style="color:#1111FF;">zenotof</B>
    └── <B style="color:#1111FF;">202304</B>
    ├── 20230402_hsapiens_Sample_001.wiff2.Zip
    ├── 20230402_hsapiens_Sample_002.wiff2.Zip
    └── 270230402_hsapiens_Sample_003.wiff2.Zip
 ...
         └── 270230402_hsapiens_Sample_099.wiff2.Zip
       </PRE>
 </DIV>


 <DIV style="padding:1em;border:2px solid gray;float:right;">
             Virtual file tree presented by ZIPsFS:
             <PRE style="font-family: monospace,courier,ariel,sans-serif;">
 ├── <B style="color:#1111FF;">brukertimstof</B>
 │   └── <B style="color:#1111FF;">202302</B>
 │       ├── <B style="color:#1111FF;">20230209_hsapiens_Sample_001.d</B>
 │       │   ├── analysis.tdf
 │       │   └── analysis.tdf_bin
 │       ├── <B style="color:#1111FF;">20230209_hsapiens_Sample_002.d</B>
 │       │   ├── analysis.tdf
 │       │   └── analysis.tdf_bin
 │       └── <B style="color:#1111FF;">20230209_hsapiens_Sample_003.d</B>
 │           ├── analysis.tdf
 │           └── analysis.tdf_bin

 ...

 │       └── <B style="color:#1111FF;">20230209_hsapiens_Sample_099.d</B>
 │           ├── analysis.tdf
 │           └── analysis.tdf_bin
 └── <B style="color:#1111FF;">zenotof</B>
     └── <B style="color:#1111FF;">202304</B>
           ├── 20230402_hsapiens_Sample_001.timeseries.data
           ├── 20230402_hsapiens_Sample_001.wiff
           ├── 20230402_hsapiens_Sample_001.wiff2
           ├── 20230402_hsapiens_Sample_001.wiff.scan
           ├── 20230402_hsapiens_Sample_002.timeseries.data
           ├── 20230402_hsapiens_Sample_002.wiff
           ├── 20230402_hsapiens_Sample_002.wiff2
           ├── 20230402_hsapiens_Sample_002.wiff.scan
           ├── 20230402_hsapiens_Sample_003.timeseries.data
           ├── 20230402_hsapiens_Sample_003.wiff
           ├── 20230402_hsapiens_Sample_003.wiff2
           └── 20230402_hsapiens_Sample_003.wiff.scan

 ...

           ├── 20230402_hsapiens_Sample_099.timeseries.data
           ├── 20230402_hsapiens_Sample_099.wiff
           ├── 20230402_hsapiens_Sample_099.wiff2
           └── 20230402_hsapiens_Sample_099.wiff.scan
 </PRE>
 </DIV>

 <DIV style="clear:both;"></DIV>

</SPAN>


EOF
}

preprocess_md(){
    local s t
    for t in _*.md; do
        local out=${t#_}
        chmod +w $out
        cp $t $out

        for s in _SNIPPET_*.md; do
            echo sssssssssssssssss $s $t
            sed -i -e "/$s/r $s" -e "/$s/d"  $out
        done
        grep  _SNIPPET_ $out && read -r -p "$out Enter"
        chmod -w $out
    done
}

DOCU_TREE=~/tmp/ZIPsFS/doc/tree
docu_f1(){
    local d0=$DOCU_TREE/mnt  f
    [[ $1 == s ]]&&d0=$DOCU_TREE/src
    shift
    for f in "$@"; do
        f=$d0/$f
        [[ -e $f ]] && continue
        mkdir -p ${f%/*} && touch $f
    done
}
main(){
    local src=${BASH_SOURCE[0]}
    cd ${src%/*} || read -r -p Enter
    local conf=src/ZIPsFS_configuration.h
    ls -l $conf || return

    local exe=~/compiled/ZIPsFS_configuration_check
    rm $exe 2>&1
    ~/sh/compile_C.sh src/${exe##*/}.c
    ! $exe && return 1


    preprocess_md
    zip -r for_the_author_only.zip  Upload_to_github.sh _INSTALL*md _SNIPPET_*.txt ZIPsFS.1.md  src/copy_from_ms03.sh src/ZIPsFS_make_release.sh
    local msg="${1:-}"
    make_man
    local out=$DIR/README.md;    chmod +w $out; make_readme   >$out;  chmod -w $out
    local out=$DIR/USE_CASE.md;  chmod +w $out; make_use_case >$out;  chmod -w $out



    echo "#define ZIPSFS_VERSION  \"$(date +%Y%m%d)\"" > src/ZIPsFS_version.h
    if [[ -z $msg ]]; then
        echo "Missing: commit message"
    else
        git commit -a -m "$msg"
        git push origin
    fi
}


main "$@"
