# Installation with autotools



This will currently work only for systems with fuse3 i.e. Linux and FreeBSD
The package autoconf is needed.

    ./configure
    cd src
    make
