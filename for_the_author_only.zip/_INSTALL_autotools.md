# Installation with autotools



This is less flexible and will only work on Linux and only with  fuse3.
It requires *make* which is in the package  build-essential.

    ./configure
    cd src
    make
