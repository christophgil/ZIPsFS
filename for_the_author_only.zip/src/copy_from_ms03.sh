#!/usr/bin/env bash
SP='sshpass -e'
[[ -z ${SSHPASS:-} ]] &&  SP=''
if [[ ${1:--} == -r ]]; then
    $SP rsync  --cvs-exclude -r -v cgille@s-mcpb-ms03.charite.de:git_projects/ZIPsFS ~/test/build/
else
    cd
    mkdir -p  ZIPsFS

    rm ZIPsFS/ZIPsFS 2>/dev/null

    p=''
    [[ -n $SSHPASS ]] && p="sshpass -e"
    $p rsync -r -v --cvs-exclude --exclude='.*'   cgille@s-mcpb-ms03.charite.de:/home/cgille/git_projects/ZIPsFS/src  ZIPsFS

    read -r -p 'Press enter to COMPILE ...'
    ZIPsFS/src/ZIPsFS.compile.sh "$@"

fi
