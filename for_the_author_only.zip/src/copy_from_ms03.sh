#!/usr/bin/env bash
SP='sshpass -e'
[[ -z ${SSHPASS:-} ]] &&  SP=''


: <<EOF

mkdir -p ~/ZIPsFS

rsync -rv cgille@s-mcpb-ms03.charite.de:git_projects/ZIPsFS/src ~/ZIPsFS/; cd ~/ZIPsFS/src

EOF

if [[ ${1:--} == -i ]]; then
    # Gehen nicht OpenBSD OpenIndiana
    export SSHPORT_FreeBSD=2224
    export SSHPORT_OpenBSD=2225
    export SSHPORT_MACOSX=2226
    export SSHPORT_OpenIndiana=2227
    export SSHPORT_OpenIndiana_min=2221
    export SSHPORT_NetBSD=2228
    export SSHPORT_omnios=2229

    alias ssh_FreeBSD='echo c c;ssh -p $SSHPORT_FreeBSD g@localhost'
    alias ssh_OpenBSD='echo c  openbsd!1 ; ssh -p $SSHPORT_OpenBSD g@localhost'
    alias ssh_MACOSX='echo gggggg; ssh -p $SSHPORT_MACOSX g@localhost'
    alias ssh_NetBSD='echo G gggggg NO-sshpass;ssh -p $SSHPORT_NetBSD g@localhost'
    alias ssh_OpenIndiana='echo c cccccc6;ssh -p $SSHPORT_OpenIndiana g@localhost'
    alias ssh_OpenIndiana_min='echo c cccccc6;ssh -p $SSHPORT_OpenIndiana_min g@localhost'
    alias ssh_omnios='echo c c;ssh -p $SSHPORT_omnios g@localhost'

elif [[ ${1:--} == -r ]]; then
    $SP rsync  --cvs-exclude -r -v cgille@s-mcpb-ms03.charite.de:git_projects/ZIPsFS ~/test/build/
else
    cd || read -r -p Enter
    mkdir -p  ZIPsFS

    rm ZIPsFS/ZIPsFS 2>/dev/null

    p=''
    [[ -n $SSHPASS ]] && p="sshpass -e"
    $p rsync -r -v --cvs-exclude --exclude='.*'   cgille@s-mcpb-ms03.charite.de:/home/cgille/git_projects/ZIPsFS/src  ZIPsFS

    read -r -p 'Press enter to COMPILE ...'
    ZIPsFS/src/ZIPsFS.compile.sh "$@"

fi
