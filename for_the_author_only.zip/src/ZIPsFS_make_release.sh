#!/usr/bin/env bash
dir=${BASH_SOURCE[0]}
cd ${dir%/*}

dir=~/tmp/ZIPsFS/release
exe=$dir/ZIPsFS_Linux_amd64
zip=$exe.zip
README=$dir/ZIPsFS_README.txt
mkdir ${dir}

[[ -s $exe ]] && rm -v $exe
[[ -s $zip ]] && rm -v $zip

cat<<EOF >$README
Please install libzip and libfuse3
On Debian/Ubuntu run as root:

 apt-get install libzip libfuse3
EOF

clang -Wstring-compare  -DHAVE_CONFIG_H -I. -I/usr/local/include/fuse3 -O0 -D_FILE_OFFSET_BITS=64 -rdynamic -g   $PWD/ZIPsFS.c -lfuse3 -lpthread -L/usr/local/lib -lm -lzip -o $exe

ls -l -h ZIPsFS.h $exe

zip -9 -j $zip $exe $README
ls -l $zip $exe $README


release=$(realpath ${BASH_SOURCE[0]})
release=${release%/*/*}/RELEASE
mkdir -p $release
cp $zip $release/
tree  $release
