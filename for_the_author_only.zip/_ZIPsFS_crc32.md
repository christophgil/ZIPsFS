## Data Integrity for ZIP Entries

For ZIP entries loaded entirely into RAM:
ZIPsFS performs CRC checksum validation.
Any detected inconsistencies are logged, helping to detect corruption or transmission errors.
