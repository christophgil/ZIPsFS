<!---
(defun Make-man()
(interactive)
(save-some-buffers t)
(shell-command "pandoc ZIPsFS.1.md -s -t man | /usr/bin/man -l -")
)
%% (query-replace-regexp " *— *" " - ")

This seems to be a common
problem of UNIX and Linux. See
https://fuse-devel.narkive.com/tkGi5trJ/trouble-with-samba-fuse-for-files-of-unknown-size.  Suggestions are welcome.

pip install grip
-->


# Example usage


    ZIPsFS [ZIPsFS-options] path-of-branch1/  branch2/  branch3/  branch4/  :  [fuse-options] mount-point


# Summary


ZIPsFS functions as a **union or overlay** file system, merging multiple file structures into a unified directory.
This directory presents the underlying files and sub-directories from the specified sources (branches) as a single, cohesive structure.
Any newly created or modified files are stored in the first file location, while all other sources remain read-only, ensuring that their files are never altered.
ZIPsFS treats **ZIP files as expandable folders**, typically naming them by appending ``.Contents/`` to the original ZIP file name.
However, this behavior can be customized using filename-based rules. Extensive configuration options allow adjustments. Changes can be applied without disrupting the file system.

With a trailing slash, the folder name is not part of the virtual path, in accordance with  the trailing slash semantics of many UNIX tools. More flexibility provides the property ``@path-prefix=...``.

ZIPsFS includes specialized features like **automatic file conversions** and performance
optimizations tailored for efficiently storing and accessing **large-scale mass spectrometry** data.
It manages non-sequential file reading from varying positions (so-called file seek) efficiently to
improve reading of remote and zipped files. It has a programming interface to create synthetic file
content programmatically.

ZIPsFS is best run in a **tmux** session.

# Mini tutorial

   Please [Install](./INSTALL.md)  ZIPsFS.


### Create some example files

Without trailing slash, the folder name will be retained in the virtual path. This is the case for ``branch3``.
Virtual file paths in that branch will start with *mount point*``/branch3/``.

    b1=~/test/ZIPsFS/writable/
    b2=~/test/ZIPsFS/branch1/
    b3=~/test/ZIPsFS/branch2/
    b4=~/test/ZIPsFS/branch3

    mkdir -p $b1 $b2 $b3 $b4 ~/test/ZIPsFS/mnt

    for c in a b c d e f; do echo hello world $c >$b2/$c.txt; done
    for ((i=0;i<10;i++)); do echo hello world $i >$b3/$i.txt; done

    zip --fifo $b2/zipfile1.zip <(date)  <(echo $RANDOM)
    zip --fifo $b3/zipfile2.zip <(hostname)  <(ls /)
    zip --fifo $b3/20250131_this_is_a_mass_spectrometry_folder.d.Zip   <(seq 10)


### Start ZIPsFS
In production, it is recommended to start ZIPsFS in *tmux*. For testing, just use your regular command line.


    ZIPsFS   $b1 $b2 $b3 $b4  :  ~/test/ZIPsFS/mnt

### Browse the virtual file tree

Open a file browser or another terminal and  browse the files in

    ~/test/ZIPsFS/mnt/

### Create a file in the virtual tree
The first file tree stores files. All others are read-only.

    echo "Hello" > ~/test/ZIPsFS/mnt/my_file.txt

    cat ~/test/ZIPsFS/mnt/my_file.txt

To get the real storage place of the file, append ``@SOURCE.TXT``

    cat ~/test/ZIPsFS/mnt/my_file.txt@SOURCE.TXT

### Access web resources as regular files (Not fully tested yet)
Make sure the UNIX tool curl is installed.

    curl --version

Note that "//:" and all slashes in the URL are replaced by commas.

    less  ~/test/ZIPsFS/mnt/ZIPsFS/n/ftp,,,ftp.uniprot.org,pub,databases,uniprot,LICENSE

    gunzip -c ~/test/ZIPsFS/mnt/ZIPsFS/n/ftp,,,ftp.ebi.ac.uk,pub,databases,uniprot,current_release,knowledgebase,complete,docs,keywlist.xml.gz


Even though the file is only available in compressed form on the server, you can directly access the decompressed file. Omit  the ``.gz`` extension.

The decompressed file size is an estimate. It becomes exactly known after reading the file.

    head ~/test/ZIPsFS/mnt/ZIPsFS/n/http,,,ftp.uniprot.org,pub,databases,uniprot,current_release,knowledgebase,reference_proteomes,Eukaryota,UP000005640,UP000005640_9606.fasta
    head ~/test/ZIPsFS/mnt/ZIPsFS/n/ftp,,,ftp.uniprot.org,pub,databases,uniprot,current_release,knowledgebase,reference_proteomes,Eukaryota,UP000005640,UP000005640_9606.fasta


    ls -l ~/test/ZIPsFS/mnt/ZIPsFS/n/ftp,,,ftp.ebi.ac.uk,pub,databases,uniprot,current_release,knowledgebase,complete,docs,keywlist.xml

    head ~/test/ZIPsFS/mnt/ZIPsFS/n/ftp,,,ftp.ebi.ac.uk,pub,databases,uniprot,current_release,knowledgebase,complete,docs,keywlist.xml

From now on, the file size is known.

The gz compression is built-in using the zlib C library. The bz2, xz and lrz
decompression work only if activated in the config (default) and if the respective backends are installed on the
computer. The following are test examples of files remotely stored as bz2 and xz, respectively.

    head ~/test/ZIPsFS/mnt/ZIPsFS/n/http,,,ftp.gnu.org,gnu,binutils,binutils-2.23.1.tar   # Remote file is .tar.bz2
    head ~/test/ZIPsFS/mnt/ZIPsFS/n/http,,,ftp.gnu.org,gnu,gawk,gawk-4.0.2.tar            # Remote file is .tar.xz


Above method allows to access any remote file. The disadvantage over the method below is, that repositories are not browsable.




</details>




<details><summary>Browsing  public repositories (Pride, Genomes, PDB, Swissprot)</summary>


Warning: this new feature is not yet fully tested!

Please install https://curlftpfs.sourceforge.net/ and curl.
Consider to add timeout like  ``curl_easy_setopt(easy,CURLOPT_TIMEOUT,3600);`` into the ``main()`` function in ``ftpfs.c``.

### Browsing FTP sites using nested Curlftpfs

The script file  [ZIPsFS_prepare_branch_for_ftp.sh](./ZIPsFS_prepare_branch_for_ftp.sh) generates an example  folder
``~/.ZIPsFS/DBcurlftpfs`` with  Curlftpfs mounts to be used in ZIPsFS.


Above command line to start ZIPsFS can extended to include this folder:

    ZIPsFS   $b1 $b2 $b3 $b4  --preload ~/.ZIPsFS/DB  :  ~/test/ZIPsFS/mnt

Due to the option ``--preload``, files are mirrord to the first branch on the local file system for fast access.
Lets try

    ls ~/test/ZIPsFS/mnt/DBcurlftpfs

GZ compressed files are transparently de-compressed. Files with the ending ``.gz`` also  appear in the file listing without gz suffix.
Initially, they have an estimated file size. After reading the virtual file, the exact length of the
decompressed data is known.

Performance:  Without a trailing slash in the command line,  the folder name  ``/DB/`` will be the beginning of virtual paths.  This
is important for performance, because it avoids that the  curlftpfs file systems will be requested for each file lookup.
Only if virtual paths start with ``/DB/``,  curlftpfs gets involved.


### Browsing FTP sites using nested Avfs

Avfs can also be used. Please see
[ZIPsFS_prepare_branch_for_ftp_avfs.sh](./ZIPsFS_prepare_branch_for_ftp_avfs.sh)



</details>


# DESCRIPTION



## ZIPsFS is a Union / overlay file system


ZIPsFS functions as a union (overlay) file system.
When files are created or modified, they are stored in the first file tree.
If a file exists in multiple source locations, the version from the leftmost source (the first one listed) takes precedence.
With an empty string as the first source,  the ZIPsFS file system read-only and file creation and modification is disabled.

The physical file path, i.e., the actual storage location of a file, can be retrieved from a
file formed by appending ``@SOURCE.TXT`` to the filename.
For example, to determine the real location of:
    ``~/test/ZIPsFS/mnt/1.txt``
Run the following command:

    cat ~/test/ZIPsFS/mnt/1.txt@SOURCE.TXT

If a remote upstream file system stops responding, the current file access is blocked (Unless the options ``WITH_ASYNC_READDIR`` ... are activated).
After some time, unresponsive upstream file trees will be skipped to prevent that file accesses get blocked.

## ZIPsFS expands ZIP file entries

By default, ZIP files are displayed as folders with the suffix ``.Content``.
This behavior can be customized.
The default configuration includes a few exceptions tailored to specific use cases in Mass Spectrometry:

  - For ZIP files whose names end with *.d.Zip*, the virtual folder will  end with *.d*.

  - Flat file list: For  Sciex instruments, each mass spectrometry record  is stored in a set of files which are not organized in
    sub-folders. For example the record ``20231122_MA_HEK_QC_hiFlow_2ug_SWATH_rep01``  stored in ``20231122_MA_HEK_QC_hiFlow_2ug_SWATH_rep01.wiff2.Zip`` may consist of the following files

     - 20231122_MA_HEK_QC_hiFlow_2ug_SWATH_rep01.timeseries.data
     - 20231122_MA_HEK_QC_hiFlow_2ug_SWATH_rep01.wiff
     - 20231122_MA_HEK_QC_hiFlow_2ug_SWATH_rep01.wiff2
     - 20231122_MA_HEK_QC_hiFlow_2ug_SWATH_rep01.wiff.scan

    These are contained with those of other entries in the file listing.
    To get the full list of files,  all ZIP files need to be inspected.
    This is time consuming and performed in the background. Consequently, the file listing will be incomplete when requested for the first time.
    Only after some seconds, the file listing will be presented properly.



## ZIPsFS Options


**-h**

Prints brief usage information.



**-s *path-of-symbolic-link**
This is discussed in section Configuration.


**-c \[NEVER,SEEK,RULE,COMPRESSED,ALWAYS\]**

Policy when ZIP entries and file content is cached in RAM.



|           |                                                                                       |
|:---------:|---------------------------------------------------------------------------------------|
|   NEVER   | ZIP entries are never cached, even not in case of backward seek.                      |
|           |                                                                                       |
|   SEEK    | ZIP entries are cached when the file position jumps backward.                         |
|           |                                                                                       |
|   RULE    | ZIP entries are cached according to customizable rules or on backward seed. (DEFAULT) |
|           |                                                                                       |
|COMPRESSED | All compressed ZIP entries are cached.                                                |
|           |                                                                                       |
|  ALWAYS   | All ZIP entries are cached.                                                           |
|           |                                                                                       |

**-l  *Maximum memory for caching ZIP-entries in the RAM***

Specifies a limit for the cache.  For example *-l  8G* would limit the size of the cache to 8 Gigabyte.
File content larger than this will not be cached. When memory usage is high, cached file access waits until it drops below this value.

**-b**
 Execution in background (Not recommended). We recommend running ZIPsFS in foreground in *tmux*.



## FUSE Options


Options for the FUSE system  come after the **colon** in the command line.

**-o *comma separated Options***

**-o allow_other**
Other users are granted access.

The last argument is the mount point which is an empty folder.


## Special directory prefixes

 - <mount-point>/ZIPsFS/p   Rapid navigation and file name searching without time consuming ZIP file expansion.
 - <mount-point>/ZIPsFS/n   Internet files. Take URL and replace colon and slashes by comma. See above tutorial.
 - <mount-point>/ZIPsFS/lrz Remote and zipped files are prefetched before reading. For FragPipe, use raw files from here.
 - <mount-point>/ZIPsFS/c   Converted files like mgf and mzML from raw mass spectrometry files or tsv from parquet files. Note that the mzML files are not suitable for FragPipe. FragPipe is generating its own mzML variant.
 - <mount-point>/ZIPsFS/1   Files of the first branch only. This includes all files ever written or generated or modified.

Details are found in the contained readme files.

## Properties of upstream file trees

In the command line, root file paths  can be followed by expressions like @immutable=1 to set specific properties.
Alternatively, properties can be written in a file ``<property-path>.ZIPsFS.properties``. This is demonstrated in   [ZIPsFS_prepare_branch_for_ftp.sh](ZIPsFS_prepare_branch_for_ftp.sh).

List (Incomplete) of root path properties:

- ``path-prefix=dir/subdir/subsubdir``  Files in this root are accessible  with paths starting with  <mount-point>/dir/subdir/subsubdir/. The last path component of the mount point can be set as path prefix simply by omitting the trailing slash.
- ``one-file-system=1``   Mount points or  symbolic links expanded in ZIPsFS can lead outside this file system and may expose sensitive files.
   With this  property, only files of the same file system will be shown. Nested mount points will be hidden.  Consider this
  property when the ZIPsFS file system is exported.
- ``follow-symlinks=1`` Symlinks are expanded within ZIPsFS. Dangerous! Consider combining with
  ``@one-file-system=1``. Expansion of symlinks with targets (realpath) outside the root path is controled by the configurable function
  ``config_allow_expand_symlink(orig_path,expanded_path)``.

- ``immutable=1``  In the respective file tree, no files are changed, deleted or created. This optimizes caching. Cached file attributs and listings will not expire.
- ``worm=1``       File tree is write-once-read-many. Same consequence as above.
- ``preload=1``    Before reading file content,  files are downloaded to the first file tree. Useful for remote files.
- ``preload-gz=1`` Files are generated from a gz-compressed files. Useful for Windows software that cannot read gnu-zipped files. Also available bz2, lrz, Z and xz.


<details><summary>Preload files</summary>


Non-linear file loading in a random-access manner is inefficient for remote or ZIP-compressed files.
This is the case for the MS-programs Diann and FragPipe (Fragger).

## File content pre-load

Remote or compressed files can be preloaded in two different ways: (I) into RAM or (II) to the local disk.

### Preloading into RAM

File names to be cached in RAM  are specified in the configurable method ``config_advise_cache_in_ram()``.  The default
setting includes Brukertimstof mass-spectrometry files. Preloading to the RAM is appropriate for these files because
each file is loaded only once per analysis. It is necessary because these mass-spectrometry files are loaded from varying file positions which would be inefficient for
remote or compressed files.
The ``-l`` option sets an upper limit on memory usage
for the ZIP RAM cache.  When available memory runs low, ZIPsFS can either pause, proceed without
caching file data or just ignore the memory restriction depending on the configuration.

### Preloading to local disk

File reading of remote or compressed files can be improved by caching the file content on the local disk.
This is for example necessary for Thermo  mass-spectrometry raw files analyzed in FragPipe.
Above method of preloading into RAM is here  inappropriate because each raw file is
opened and closed multiple times during computation such that the large files would be transfered from the NAS several times.

All remote (r) or compressed (c) or zippded (z) files
accessed through the following folders will be first copied to local disk:

    <mount-point>/ZIPsFS/lr/
    <mount-point>/ZIPsFS/lrc/
    <mount-point>/ZIPsFS/lrz/

The Readme in these folders provide further information.
Alternatively, the entire root-path can be marked for preloading with the property ``@preload``.
Decompression is enabled with properties like ``@preload-gz``

</details>


<details><summary>Project status</summary>

Author: Christoph Gille

**Current status**: Testing and Bug fixing. Already running very busy for several weeks without interruption.


If ZIPsFS crashes, please send the stack-trace together with the source code you were using.

</details>
