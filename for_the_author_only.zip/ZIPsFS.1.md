<!---
(defun Make-man()
(interactive)
(save-some-buffers t)
(shell-command "pandoc ZIPsFS.1.md -s -t man | /usr/bin/man -l -")
)
%% (query-replace-regexp " *— *" " - ")

This seems to be a common
problem of UNIX and Linux. See
https://fuse-devel.narkive.com/tkGi5trJ/trouble-with-samba-fuse-for-files-of-unknown-size.  Suggestions are welcome.

pip install grip
-->


# Example usage


    ZIPsFS [ZIPsFS-options] path-of-branch1/  branch2/  branch3/  branch4/  :  [fuse-options] mount-point


# Summary


ZIPsFS functions as a **union or overlay** file system, merging multiple file structures into a unified directory.
This directory presents the underlying files and sub-directories from the specified sources (branches) as a single, cohesive structure.
Any newly created or modified files are stored in the first file location, while all other sources remain read-only, ensuring that their files are never altered.
ZIPsFS treats **ZIP files as expandable folders**, typically naming them by appending ``.Contents/`` to the original ZIP file name.
However, this behavior can be customized using filename-based rules. Extensive configuration options allow adjustments. Changes can be applied without disrupting the file system.

With a trailing slash, the folder name is not part of the virtual path, in accordance with  the trailing slash semantics of many UNIX tools.
More flexibility provides the property ``@path-prefix=...``.

ZIPsFS includes specialized features like **automatic file conversions** and performance
optimizations tailored for efficiently storing and accessing **large-scale mass spectrometry** data.
It manages non-sequential file reading from varying positions (so-called file seek) efficiently to
improve reading of remote and zipped files. With file-preload-to-disk, it manages files in remote FTP repositories as if they were normal local files.
Compressed (gz,xz,bz2,lrz,Z)  can be transparently decompressed.
It has a programming interface to create synthetic file
content programmatically.

ZIPsFS is best run in a **tmux** session.

# Mini tutorial

   Please [Install](./INSTALL.md)  ZIPsFS.


### Create some example files

Without trailing slash, the folder name will be retained in the virtual path. This is the case for ``branch3``.
Virtual file paths in that branch will start with *mount point*``/branch3/``.

    b1=~/test/ZIPsFS/writable/
    b2=~/test/ZIPsFS/branch1/
    b3=~/test/ZIPsFS/branch2/
    b4=~/test/ZIPsFS/branch3

    mkdir -p $b1 $b2 $b3 $b4 ~/test/ZIPsFS/mnt

    for c in a b c d e f; do echo hello world $c >$b2/$c.txt; done
    for ((i=0;i<10;i++)); do echo hello world $i >$b3/$i.txt; done

    zip --fifo $b2/zipfile1.zip <(date)  <(echo $RANDOM)
    zip --fifo $b3/zipfile2.zip <(hostname)  <(ls /)
    zip --fifo $b3/20250131_this_is_a_mass_spectrometry_folder.d.Zip   <(seq 10)


### Start ZIPsFS
In production, it is recommended to start ZIPsFS in *tmux*. For testing, just use your regular command line.


    ZIPsFS   $b1 $b2 $b3 $b4  :  ~/test/ZIPsFS/mnt

### Browse the virtual file tree

Open a file browser or another terminal and  browse the files in

    ~/test/ZIPsFS/mnt/


# Tutorial on further features

### Create a file in the virtual tree
The first file tree stores files. All others are read-only.

    echo "Hello" > ~/test/ZIPsFS/mnt/my_file.txt

    cat ~/test/ZIPsFS/mnt/my_file.txt

To get the real storage place of the file, append ``@SOURCE.TXT``

    cat ~/test/ZIPsFS/mnt/my_file.txt@SOURCE.TXT

More information is available with suffix ``@PROPRERTIES.TXT``

    cat ~/test/ZIPsFS/mnt/my_file.txt@PROPRERTIES.TXT

### Access web resources as regular files (Not fully tested yet)
Make sure the UNIX tool curl is installed.

    curl --version

Note that "//:" and all slashes in the URL are replaced by commas.

    less  ~/test/ZIPsFS/mnt/zipsfs/n/ftp,,,ftp.uniprot.org,pub,databases,uniprot,LICENSE

    gunzip -c ~/test/ZIPsFS/mnt/zipsfs/n/ftp,,,ftp.ebi.ac.uk,pub,databases,uniprot,current_release,knowledgebase,complete,docs,keywlist.xml.gz


Even though the file is only available in compressed form on the server, you can directly access the decompressed file. Omit  the ``.gz`` extension.

The decompressed file size is an estimate. It becomes exactly known after reading the file.

    head ~/test/ZIPsFS/mnt/zipsfs/n/http,,,ftp.uniprot.org,pub,databases,uniprot,current_release,knowledgebase,reference_proteomes,Eukaryota,UP000005640,UP000005640_9606.fasta
    head ~/test/ZIPsFS/mnt/zipsfs/n/ftp,,,ftp.uniprot.org,pub,databases,uniprot,current_release,knowledgebase,reference_proteomes,Eukaryota,UP000005640,UP000005640_9606.fasta


    ls -l ~/test/ZIPsFS/mnt/zipsfs/n/ftp,,,ftp.ebi.ac.uk,pub,databases,uniprot,current_release,knowledgebase,complete,docs,keywlist.xml

    head ~/test/ZIPsFS/mnt/zipsfs/n/ftp,,,ftp.ebi.ac.uk,pub,databases,uniprot,current_release,knowledgebase,complete,docs,keywlist.xml

From now on, the file size is known.

The gz compression is built-in using the zlib C library. The bz2, xz and lrz
decompression work only if activated in the config (default) and if the respective backends are installed on the
computer. The following are test examples of files remotely stored as bz2 and xz, respectively.

    head ~/test/ZIPsFS/mnt/zipsfs/n/http,,,ftp.gnu.org,gnu,binutils,binutils-2.23.1.tar   # Remote file is .tar.bz2
    head ~/test/ZIPsFS/mnt/zipsfs/n/http,,,ftp.gnu.org,gnu,gawk,gawk-4.0.2.tar            # Remote file is .tar.xz


Above method allows to access any remote file. The disadvantage over the method below is, that repositories are not browsable.





### Browsing FTP sites using nested FUSE file systems


There are 3 FUSE file systems that could be nested into ZIPsFS to access remote FTP sites: curlftpfs, rclone and avfs.
All of them are great for file browsing of the remote files. However, downloading very large files seems to be problematic.
As a workaround, ZIPsFS can use ***curl*** which is a very robust and  efficient at loading remote files. It should be installed.
ZIPsFS needs the equivalent URL.  For convenience we provide the script
file  [ZIPsFS_prepare_branch_for_ftp.sh](./ZIPsFS_prepare_branch_for_ftp.sh) which takes care of this. It may be used as a template.
It creates folders like ``~/.ZIPsFS/db/pride``
and mounts the respective FTP sites. This requires ***curl***. Please also install  ***rclone*** (or curlftpfs).


The  standard output of the script can be used  as command line  parameters for ZIPsFS.
The expression ``$(...)`` denotes [Command substitution](https://en.wikipedia.org/wiki/Command_substitution).

    ZIPsFS   $b1 $b2 $b3 $b4  $(./ZIPsFS_prepare_branch_for_ftp.sh)   :  ~/test/ZIPsFS/mnt

In case of success, there will be a directory:

    ls ~/test/ZIPsFS/mnt/db

Files with the ending ``.gz`` also  appear in the file listing without gz suffix.

But wait, there is a major problem.  Before decompression, ZIPsFS can only communicate an estimated file size of the decompressed file.
Consequently, programs that depend on exact file sizes will not work. Most UNIX tools do not need the file size. A text book example of a UNIX tool that does require
the size of the file is  ``/usr/bin/tail``. Lets see what happens if ZIPsFS tells a wrong size.  Please try


    tail  ~/test/ZIPsFS/mnt/mnt/db/pride/2005/08/PRD000004/PRIDE_Exp_Complete_Ac_369.xml

The first time the ``tail`` command is run, there will be no  output.
Subsequently, ``tail`` works nicely, because then the file size is known.

To repeat the test,  the preloaded file can be removed

    rm  ~/test/ZIPsFS/mnt/mnt/db/pride/2005/08/PRD000004/PRIDE_Exp_Complete_Ac_369.xml




# DESCRIPTION



## ZIPsFS is a Union / overlay file system


ZIPsFS functions as a union (overlay) file system.
When files are created or modified, they are stored in the first file tree.
If a file exists in multiple source locations, the version from the leftmost source (the first one listed) takes precedence.
With an empty string as the first source,  the ZIPsFS file system read-only and file creation and modification is disabled.

The physical file path, i.e., the actual storage location of a file, can be retrieved from a
file formed by appending ``@SOURCE.TXT`` to the filename.
For example, to determine the real location of:
    ``~/test/ZIPsFS/mnt/1.txt``
Run the following command:

    cat ~/test/ZIPsFS/mnt/1.txt@SOURCE.TXT

If a remote  file branch system stops responding, the current file access is blocked (Unless the options ``WITH_ASYNC_READDIR`` ... are activated).
After some time, unresponsive  file trees will be skipped to prevent that file accesses get blocked.


## ZIPsFS expands ZIP file entries

By default, ZIP files are displayed as folders with the suffix ``.Content``.
This behavior can be customized.
The default configuration includes a few exceptions tailored to specific use cases in Mass Spectrometry:

  - For ZIP files whose names end with *.d.Zip*, the virtual folder will  end with *.d*.

  - Flat file list: For  Sciex instruments, each mass spectrometry record  is stored in a set of files which are not organized in
    sub-folders. For example the record ``20231122_MA_HEK_QC_hiFlow_2ug_SWATH_rep01``  stored in ``20231122_MA_HEK_QC_hiFlow_2ug_SWATH_rep01.wiff2.Zip`` may consist of the following files

     - 20231122_MA_HEK_QC_hiFlow_2ug_SWATH_rep01.timeseries.data
     - 20231122_MA_HEK_QC_hiFlow_2ug_SWATH_rep01.wiff
     - 20231122_MA_HEK_QC_hiFlow_2ug_SWATH_rep01.wiff2
     - 20231122_MA_HEK_QC_hiFlow_2ug_SWATH_rep01.wiff.scan

    These are contained with those of other entries in the file listing.
    To get the full list of files,  all ZIP files need to be inspected.
    This is time consuming and performed in the background. Consequently, the file listing will be incomplete when requested for the first time.
    Only after some seconds, the file listing will be presented properly.

A major advantage of using ZIP archives for storing files is that
Zip files contain a record of the CRC32 checksum of each zip entry. This can be used for integrity checks to detect data decay or problems with data transfer.
This checksum can be obtained from ZIPsFS by appending ``@ARCHIVECRC32.TXT`` to a file path.


## Command line Options


**-h**

Prints brief usage information.



**-s *path-of-symbolic-link**
This is discussed in section Configuration.


**-c \[NEVER,SEEK,RULE,COMPRESSED,ALWAYS\]**

Policy when ZIP entries and file content is cached in RAM.



|           |                                                                                       |
|:---------:|---------------------------------------------------------------------------------------|
|   NEVER   | ZIP entries are never cached, even not in case of backward seek.                      |
|           |                                                                                       |
|   SEEK    | ZIP entries are cached when the file position jumps backward.                         |
|           |                                                                                       |
|   RULE    | ZIP entries are cached according to customizable rules or on backward seed. (DEFAULT) |
|           |                                                                                       |
|COMPRESSED | All compressed ZIP entries are cached.                                                |
|           |                                                                                       |
|  ALWAYS   | All ZIP entries are cached.                                                           |
|           |                                                                                       |

**-l  *Maximum memory for caching ZIP-entries in the RAM***

Specifies a limit for the cache.  For example *-l  8G* would limit the size of the cache to 8 Gigabyte.
File content larger than this will not be cached. When memory usage is high, cached file access waits until it drops below this value.

**-b**
 Execution in background (Not recommended). We recommend running ZIPsFS in foreground in *tmux*.


These rules can be overridden by using the sub-directories ``/zipsfs/-/m/`` and ``/zipsfs/-/-m/``. Please see the README files in these folders.


## FUSE command line options


Options for the FUSE system  come after the **colon** in the command line.

**-o *comma separated Options***

**-o allow_other**
Other users are granted access.

The last argument is the mount point which is an empty folder.


## Special directory  <mount-point>``/zipsfs/``

The folder <mount-point>``/zipsfs/`` provides alternative views and file prefetch.
It contains log files and scripts.
The file tree can be accessed in a modified way via

    /zipsfs/<view-option>/<file preload-option>[/<preload-selector>]

These three folders contain single letter directives which take precedence over root-folder settings at the command line.
Directives are negated when preceded by dash. Detailed descriptions are found in the README files in these folders
and [here](./special_folders).


### View-option

The first subfolder contains directive to specify

 - Whether  the 1st root / the other roots are included / excluded.
 - Whether ZIP files are expanded.
 - Whether converted files are presented along with the original files.
   Implemented examples:  OCR generated texts from image files and  mzML files from proprietary mass-spectrometry files.
 - Whether decompressed files are generated for gz, bz2, Z,  xz and lrz compressed files.

The folder ``/n/`` allows access to internet files. The file name is formed from URLs by replacing the colon and the slashes by comma.

### Preload option

The 2nd subfolder contains preload options.
  - /-/ Apply  default preload rules defined in ``ZIPsFS_configuration.c`` and ``ZIPsFS_configuration.h`` and specified by root properties.
  - /m/ Prefetch to RAM
  - /l/ Prefetch to the local file system
  - /lz/ Prefetch to the local file system. Instead of single entries, load entire ZIP files to local disk.
    The directive ``z`` is different from a ``z`` in the 3rd folder where it acts as a selector. How the ZIP entries are read from that locally cached ZIP file
    depends entirely on rules in the config files.  ZIP entries may be read directly or with preloading into RAM.  The later case represents a combination of
    preload to disk and RAM.

### Preload selector

If the 2nd subfolder declares file preload, then the 3rd subfolder gives the condition.
 - a all
 - r remote
 - z ZIP-entry.


## Properties of file branches

In the command line, root file paths  can be followed by expressions like @immutable=1 to set specific properties.
Alternatively, properties can be given in a file ``<root-path>.ZIPsFS.properties``. This is demonstrated in   [ZIPsFS_prepare_branch_for_ftp.sh](ZIPsFS_prepare_branch_for_ftp.sh).

For a  list of properties  run

    ZIPsFS -h


<details><summary>Preload files</summary>


Non-linear file loading in a random-access manner is very common for Windows style software were pipes and process substitution are rarely used.
This is also the case for the widely used mass-spectrometry programs Diann and FragPipe (Fragger).
Vendor specific mass-spectrometry files are loaded from varying file positions.
Apparently, this mode of file access is inefficient for remote or ZIP-compressed data.

## File content preload

Data preloading can help to provide file data out-of-order.
Remote or compressed files can be preloaded in two different ways: (I) into RAM or (II) to the local disk.

### Preloading into RAM

File names to be cached in RAM  are specified in the configurable method ``config_advise_cache_in_ram()``.  The default
setting includes Brukertimstof mass-spectrometry files. Preloading to the RAM is appropriate for these files because
each file is loaded only once per analysis.
The ``-l`` option sets an upper limit on memory usage
for the ZIP RAM cache.  When available memory runs low, ZIPsFS can either pause, proceed without
caching file data or just ignore the memory restriction depending on the configuration.

### Preloading to local disk

File reading of remote or compressed files can be improved by caching the file content on the local disk.
This is for example necessary for Thermo  mass-spectrometry raw files analyzed in FragPipe.
Above method of preloading into RAM is here  inappropriate because each raw file is
opened and closed multiple times during computation such that the large files would be transferred over the net several times.


### Transiently caching  file attributes and directory listings


When loading Bruker mass spectrometry files with the Bruker DLLs, The file system is asked
dozens of times per second to provide one and the same file listing and the same file
attributes.  While this so-called stat-spamming is fine for local files, remote file systems and decompressing file reading  get overloaded.
ZIPsFS  implements a transient cache, that lives as long as the specific ZIP file is used.

This cache is distinct from a persistent cache of directory listing that may last for ever for root
branches with the property @immutable.


</details>


<details><summary>Project status</summary>

Author: Christoph Gille

**Current status**: Testing and Bug fixing. Occasionally improving concepts. Already running very busy for several weeks without interruption.


If ZIPsFS crashes, please send the stack-trace together with the source code you were using.

</details>



## End ZIPsFS

ZIPsFS can be killed like any UNIX command by typing  Ctrl-C.
Sometimes this does not work. Assuming mnt is your mount-point, the following might work:

    fusermount -u mnt
    sudo umount mnt

If ZIPsFS still hangs, the following will kill all FUSE file systems of the current user.
Those of other users won't be affected:

    echo 1 | sudo tee /sys/fs/fuse/connections/*/abort

To kill only the specific fuse mount you need to put the minor device number instead of the asterisk.
Look at the third column of the command output containing the major:minor device number, e.g., 0:42.
The minor number (42) matches the folder name in /sys/fs/fuse/connections/42/.

    grep fuse /proc/self/mountinfo

## Change-log

- 202601
   - Changing ZIPsFS to lower-case in <mount-point>/zipsfs. This was necessary to export  ZIPsFS as a Samba Share to Windows
- 202610
   - Re-organized the <mount-point>/zipsfs file branch.
   - Solved problem of file truncation due to underestimated file size
