<!---
(defun Make-man()
(interactive)
(save-some-buffers t)
(shell-command "pandoc ZIPsFS.1.md -s -t man | /usr/bin/man -l -")
)
%% (query-replace-regexp " *— *" " - ")

This seems to be a common
problem of UNIX and Linux. See
https://fuse-devel.narkive.com/tkGi5trJ/trouble-with-samba-fuse-for-files-of-unknown-size.  Suggestions are welcome.

pip install grip
-->


# Example usage

    ZIPsFS [ZIPsFS-options] path-of-branch1/  branch2/  branch3/  branch4/  :  [fuse-options] mount-point

    ZIPsFS -h
# Summary


ZIPsFS functions as a **union or overlay** file system, merging multiple file structures into a unified directory.
This directory presents the underlying files and sub-directories from the specified source trees (branches) as a single, cohesive structure.
Any newly created or modified files are stored in the first file location, while all other sources remain read-only, ensuring that their files are never altered.
ZIPsFS treats **ZIP files as expandable folders**, typically naming them by appending ``.Contents/`` to the original ZIP file name.
However, this behavior can be customized using filename-based rules. Extensive configuration options allow adjustments. Changes can be applied without disrupting the file system.

With a trailing slash, the folder name is not part of the virtual path, in accordance with  the trailing slash semantics of many UNIX tools.
More flexibility provides the property ``@path-prefix=...``.

ZIPsFS includes specialized features like **automatic file conversions** and performance
optimizations tailored for efficiently storing and accessing **large-scale** data.
It manages non-sequential file reading from varying positions (so-called file seek) efficiently to
improve reading of remote and zipped files. With file-preload-to-disk, it manages files in remote FTP repositories as if they were normal local files.
Compressed (gz,xz,bz2,lrz,Z)  can be transparently decompressed.
It has a programming interface to create synthetic file
content programmatically.

# Mini tutorial

   Please [Install](./INSTALL.md)  ZIPsFS.


### Create some example files

Without trailing slash, the folder name will be retained in the virtual path. This is the case for ``branch3``.
Virtual file paths in that branch will start with *mount point*``/branch3/``.

    b1=~/test/ZIPsFS/writable/
    b2=~/test/ZIPsFS/branch1/
    b3=~/test/ZIPsFS/branch2/
    b4=~/test/ZIPsFS/branch3

    mkdir -p $b1 $b2 $b3 $b4 ~/test/ZIPsFS/mnt

    for c in a b c d e f; do echo hello world $c >$b2/$c.txt; done
    for ((i=0;i<10;i++)); do echo hello world $i >$b3/$i.txt; done

    zip --fifo $b2/zipfile1.zip <(date)  <(echo $RANDOM)
    zip --fifo $b3/zipfile2.zip <(hostname)  <(ls /)
    zip --fifo $b3/20250131_this_is_a_mass_spectrometry_folder.d.Zip   <(seq 10)


### Start ZIPsFS
Run:


    ZIPsFS   $b1 $b2 $b3 $b4  : -o allow_other  ~/test/ZIPsFS/mnt


Note that Tmux is very robust and ZIPsFS can be run in a Tmux window for several month without interruption.
The advantage of running ZIPsFS in the foreground in Tmux is that the log output can be observed easily.

### Browse the virtual file tree

Open a file browser or another terminal and  browse the files in

    ~/test/ZIPsFS/mnt/


# Tutorial on further features

### Create a file in the virtual tree
The first file tree stores files. All others are read-only.

    echo "Hello" > ~/test/ZIPsFS/mnt/my_file.txt

    cat ~/test/ZIPsFS/mnt/my_file.txt

To get the real storage place of the file, append ``@SOURCE.TXT``

    cat ~/test/ZIPsFS/mnt/my_file.txt@SOURCE.TXT

More information is available with suffix ``@PROPERTIES.TXT``

    cat ~/test/ZIPsFS/mnt/my_file.txt@PROPRERTIES.TXT

### Access web resources as regular files (Not fully tested yet)
Make sure the UNIX tool curl is installed.

    curl --version

Take an URL and replace  "//:" and all slashes by commas. Give it some time as the file needs to be downloaded to disk.

    less  ~/test/ZIPsFS/mnt/zipsfs/n/ftp,,,ftp.uniprot.org,pub,databases,uniprot,LICENSE

    gunzip -c ~/test/ZIPsFS/mnt/zipsfs/n/ftp,,,ftp.ebi.ac.uk,pub,databases,uniprot,current_release,knowledgebase,complete,docs,keywlist.xml.gz

    gunzip -c  ftp,,,ftp.expasy.org,databases,uniprot,current_release,knowledgebase,reference_proteomes,Viruses,UP001733680,UP001733680_2006137.fasta.gz


Even though the file is stored as a  compressed file, you can directly access the decompressed file. Omit  the ``.gz`` extension and display the file with ``cat``.

Please note, that the size of the decompressed file is estimated. It becomes exactly known after
reading the file.  While gz decompression works without external programs, bz2, xz, Z and lrz
decompression require respective UNIX tools to be installed.


Examples of files remotely stored as bz2 and xz:

    head ~/test/ZIPsFS/mnt/zipsfs/n/http,,,ftp.gnu.org,gnu,binutils,binutils-2.23.1.tar   # Remote file is .tar.bz2
    head ~/test/ZIPsFS/mnt/zipsfs/n/http,,,ftp.gnu.org,gnu,gawk,gawk-4.0.2.tar            # Remote file is .tar.xz


### Browsing FTP sites using nested FUSE file systems

Please install  ***curl*** and   ***rclone*** (or curlftpfs).

There are FUSE file systems  to access remote FTP sites: Curlftpfs, Rclone and Avfs.
They can be nested into ZIPsFS.
All of them are great for file browsing in FTP repositories. However, downloading very large files seems to be problematic.
As a workaround, ZIPsFS can use the robust and fast utility ***curl***.
ZIPsFS uses ***curl*** if there is a file ~mount-point.URL~  telling the equivalent URL.   Please find the
file  [ZIPsFS_prepare_branch_for_ftp.sh](./ZIPsFS_prepare_branch_for_ftp.sh). It sets things up for a few example databases and  can be used as a template.
It creates folders like ``~/.ZIPsFS/db/pride``



The  standard output of the script can be used  as command line  parameters for ZIPsFS.
The expression ``$(...)`` denotes [Command substitution](https://en.wikipedia.org/wiki/Command_substitution).

    ZIPsFS   $b1 $b2 $b3 $b4  $(./ZIPsFS_prepare_branch_for_ftp.sh)   : -o allow_other  ~/test/ZIPsFS/mnt

In case of success, there will be a directory:

    ls ~/test/ZIPsFS/mnt/db

Files with the ending ``.gz`` also  appear in the file listing without gz suffix because the script adds the property ``decompression=gz,bz2,Z``.

But wait, there is a major problem.  Before decompression, ZIPsFS can only communicate an estimated file size of the decompressed file.
Consequently, programs that depend on exact file sizes will not work. Most UNIX tools do not need the file size. However,
  ``/usr/bin/tail`` does. Lets see what happens if ZIPsFS provides a wrong size.  Please try


    tail  ~/test/ZIPsFS/mnt/mnt/db/pride/2005/08/PRD000004/PRIDE_Exp_Complete_Ac_369.xml

The first time the ``tail`` command is run, there will be no  output.
Subsequently, ``tail`` works nicely, because then the file size is known.

To repeat the test,  the preloaded file can be removed

    rm  ~/test/ZIPsFS/mnt/mnt/db/pride/2005/08/PRD000004/PRIDE_Exp_Complete_Ac_369.xml




# DESCRIPTION



## ZIPsFS is a Union / overlay file system


ZIPsFS functions as a union (overlay) file system.
When files are created or modified, they are stored in the first file tree.
If a file exists in multiple source trees, the version from the leftmost source (the first one listed) takes precedence.
With an empty string as the first source,  the ZIPsFS file system read-only and file creation and modification is disabled.

The physical file path, i.e., the actual storage location of a file, can be retrieved from a
file formed by appending ``@SOURCE.TXT`` to the filename.
For example, to determine the real location of:
    ``~/test/ZIPsFS/mnt/1.txt``
Run the following command:

    cat ~/test/ZIPsFS/mnt/1.txt@SOURCE.TXT

If a remote  source tree  stops responding, the current file access is blocked (Unless the options ``WITH_ASYNC_READDIR`` ... are activated).
After some time, unresponsive  file trees will be skipped to prevent that file accesses get blocked.


## ZIPsFS expands ZIP file entries

By default, ZIP files are displayed as folders with the suffix ``.Content``.
This behavior can be customized.
The default rules are tailored to specific use cases in Mass Spectrometry:

  - For ZIP files whose names end with *.d.Zip*, the virtual folder will  end with *.d*.

  - Flat file list (Try ZIPsFS_testfiles_zipflat.sh): For  Sciex instruments, each mass spectrometry record  is stored in a set of files which are not organized in
    sub-folders. For example the record ``20231122_MA_HEK_QC_hiFlow_2ug_SWATH_rep01``  stored in ``20231122_MA_HEK_QC_hiFlow_2ug_SWATH_rep01.wiff2.Zip`` may consist of the following files

     - 20231122_MA_HEK_QC_hiFlow_2ug_SWATH_rep01.timeseries.data
     - 20231122_MA_HEK_QC_hiFlow_2ug_SWATH_rep01.wiff
     - 20231122_MA_HEK_QC_hiFlow_2ug_SWATH_rep01.wiff2
     - 20231122_MA_HEK_QC_hiFlow_2ug_SWATH_rep01.wiff.scan

    These are contained with those of other entries in one long  file listing.
    For ZIPsFS, it is time consuming to inspect all ZIP files to generate the full listing. This work is performed in a separate thread to not block the user thread.
    Initially, the file listing may still contain ``.Content`` folders from ZIP files that are not yet expanded.

A major advantage of using ZIP archives for storing files is that
Zip files contain a record of the CRC32 checksum of each zip entry. This can be used for integrity checks to detect data decay or problems with data transfer.
This checksum can be obtained from ZIPsFS by appending ``@ARCHIVECRC32.TXT`` to a file path.




## Path encoded options




The folder <mount-point>``/zipsfs/`` provides alternative access paths to alter the view of the file tree and  file content  preload

    /zipsfs/<view-option>/<file preload-option>[/<preload-selector>]

These three folders contain single letter directives.
For example a file

     <mountpoint>/foo/bar.txt

can also be accessed from

    <mountpoint>/zipsfs/z/l/r/foo/bar.txt
                        │ │ │
                        │ │ └── Selector: Apply to files from remote sites
                        │ └──── Preload option: Preload to disk
                        └────── View option: Do not expand ZIP files. Show ZIP files as ZIP files.


Path encoded options take precedence over source tree settings.
Directives are negated when preceded by dash. Detailed descriptions are found in the README files in these folders.  [here](./special_folders.md) are all READMEs concatenated.



### Choosing the access path

To chose the optimal access path for a particular software and data storage features need to be considered.

 - Are the files remote? Does  file transfer take long?
 - For long file transfers: Is the application opening each file several times or just once?
 - Are the files
    - Regular
    - Compressed or uncompressed ZIP entries
    - Compressed files (gz, bz2, xz, Z, lrz) which the software does not support
 - Does the software read files sequentially or from varying positions
 - Does the software repeatedly request file attributes and folder listings at a high frequency - so-called  stat-spamming?
   This has been observed in software using SQLite databases as file format. Unless SQLite databases are preloaded,
   Severe NAS performance problems may occur.



The following suggest access paths for specific applications in mass-spectrometry:

 - ``/``                Default  options are appropriate for Diann. No view prefix necessary.
 - ``/zipsfs/d/lz/r/``  Fragpipe, Maxquant,   Diann on far remote files (Pride-DB, Massive-DB, cloud storage)
 - ``/zipsfs/z/l/r/``   Upload to Pride. Before starting Pride, read the beginning of all files to force local caching of NAS files.
 - ``/zipsfs/z/-/``     Upload to Massive, fast file browsing (Windows explorer)


### View-option

The flags in the first subfolder  specify

 - Whether the 1st source tree or the other source trees are included or excluded.
 - Whether ZIP files are expanded.
 - Whether converted files are presented along with the original files.
   Implemented examples:  OCR generated texts from image files and  mzML files from proprietary mass-spectrometry files.
 - Whether decompressed files are generated for gz, bz2, Z,  xz and lrz compressed files.

The folder ``/zipsfs/n/`` allows access to internet files.  File names are formed from URLs by replacing the colon and slashes by comma.

### Preload option

The 2nd subfolder contains preload options.
  - ``/-/`` Apply  default preload rules specified in ``ZIPsFS_configuration.c``,  ``ZIPsFS_configuration.h`` and  source tree properties.
  - ``/m/`` Prefetch to RAM
  - ``/l/`` Prefetch to the local file system
  - ``/lz/`` Prefetch to the local file system. Instead of single entries, load entire ZIP files to local disk. Whether and how the entries are preloaded
    would be specified in the 2nd subfolder. E.g.  ``/lz/m/a``  cache all entries in RAM.

### Preload selector

If the 3rd subfolder declares file preload to RAM or disk, then the 3rd subfolder gives the condition. Combinations are  combined with logic or.
 - ``a`` all
 - ``r`` remote
 - ``z`` ZIP-entry


## Properties of source trees

In the command line, source trees are specified by their root paths. They  can be followed by expressions like @immutable=1 to set specific properties.
Alternatively, properties can be given in a file ``<root-path>.ZIPsFS.properties``. This is demonstrated in   [ZIPsFS_prepare_branch_for_ftp.sh](ZIPsFS_prepare_branch_for_ftp.sh).

For a  list of properties  run

    ZIPsFS -h


<details><summary>Preload files</summary>


Non-linear file loading in a random-access manner is very common for Windows style software were pipes and process substitution are rarely used.
This is also the case for the widely used mass-spectrometry programs Diann and FragPipe (Fragger).
Vendor specific mass-spectrometry files are loaded from varying file positions.
Apparently, this mode of file access is inefficient for remote or ZIP-compressed data.

## File content preload

Data preloading can help to provide file data out-of-order.
Remote or compressed files can be preloaded in two different ways: (I) into RAM or (II) to the local disk.

### Preloading into RAM

File names to be cached in RAM  are specified in the configurable method ``config_advise_cache_in_ram()``.  The default
setting includes Brukertimstof mass-spectrometry files. Preloading to the RAM is appropriate for these files because
each file is loaded only once per analysis.
The ``-l`` option sets an upper limit on memory usage
for the ZIP RAM cache.  When available memory runs low, ZIPsFS can either pause, proceed without
caching file data or just ignore the memory restriction depending on the configuration.

### Preloading to local disk

File reading of remote or compressed files can be improved by caching the file content on the local disk.
This is for example necessary for Thermo  mass-spectrometry raw files analyzed in FragPipe.
Above method of preloading into RAM is here  inappropriate because each raw file is
opened and closed multiple times during computation such that the large files would be transferred over the net several times.


### Transiently caching  file attributes and directory listings


When loading Bruker mass spectrometry files with the Bruker DLLs, The file system is asked
dozens of times per second to provide one and the same file listing and the same file
attributes.  While this so-called stat-spamming is fine for local files, remote file systems and decompressing file reading  get overloaded.
ZIPsFS  implements a transient cache, that lives as long as the specific ZIP file is used.

This cache is distinct from a persistent cache of directory listing.

</details>


<details><summary>Project status</summary>

Author: Christoph Gille

**Current status**: Testing and Bug fixing. Occasionally improving concepts. Already running very busy for several weeks without interruption.


If ZIPsFS crashes, please send the stack-trace together with the source code you were using.

</details>



## Kill ZIPsFS

ZIPsFS can be killed like any UNIX command by typing  Ctrl-C.
Sometimes this does not work. Assuming mnt is your mount-point, the following might work:

    fusermount -u mnt
    sudo umount mnt

If ZIPsFS still hangs, the following will kill all FUSE file systems of the current user.
Those of other users won't be affected:

    echo 1 | sudo tee /sys/fs/fuse/connections/*/abort

To kill only the specific fuse mount you need to put the minor device number instead of the asterisk.
Look at the third column of the command output containing the major:minor device number, e.g., 0:42.
The minor number (42) matches the folder name in /sys/fs/fuse/connections/42/.

    grep fuse /proc/self/mountinfo

## Change-log

- 202601
   - Changing ZIPsFS to lower-case in <mount-point>/zipsfs. This was necessary to export  ZIPsFS as a Samba Share to Windows
- 202610
   - Re-organized the <mount-point>/zipsfs file branch.
   - Solved problem of file truncation due to underestimated file size
