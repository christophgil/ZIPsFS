<!---
(defun Make-man()
(interactive)
(save-some-buffers t)
(shell-command "pandoc ZIPsFS.1.md -s -t man | /usr/bin/man -l -")
)
%% (query-replace-regexp " *— *" " - ")

This seems to be a common
problem of UNIX and Linux. See
https://fuse-devel.narkive.com/tkGi5trJ/trouble-with-samba-fuse-for-files-of-unknown-size.  Suggestions are welcome.

pip install grip
-->


# Example usage


    ZIPsFS [ZIPsFS-options] path-of-branch1/  branch2/  branch3/  branch4/  :  [fuse-options] mount-point


# Summary


ZIPsFS functions as a **union or overlay** file system, merging multiple file structures into a unified directory.
This directory presents the underlying files and sub-directories from the specified sources (branches) as a single, cohesive structure.
Any newly created or modified files are stored in the first file location, while all other sources remain read-only, ensuring that their files are never altered.
ZIPsFS treats **ZIP files as expandable folders**, typically naming them by appending ``.Contents/`` to the original ZIP file name.
However, this behavior can be customized using filename-based rules. Extensive configuration options allow adjustments. Changes can be applied without disrupting the file system.

With a trailing slash, the folder name is not part of the virtual path, in accordance with  the trailing slash semantics of many UNIX tools.
More flexibility provides the property ``@path-prefix=...``.   Run ``ZIPsFS -h`` for a list of properties.

ZIPsFS includes specialized features like **automatic file conversions** and performance
optimizations tailored for efficiently storing and accessing **large-scale mass spectrometry** data.
It manages non-sequential file reading from varying positions (so-called file seek) efficiently to
improve reading of remote and zipped files. It has a programming interface to create synthetic file
content programmatically.

ZIPsFS is best run in a **tmux** session.

# Mini tutorial

   Please [Install](./INSTALL.md)  ZIPsFS.


### Create some example files

Without trailing slash, the folder name will be retained in the virtual path. This is the case for ``branch3``.
Virtual file paths in that branch will start with *mount point*``/branch3/``.

    b1=~/test/ZIPsFS/writable/
    b2=~/test/ZIPsFS/branch1/
    b3=~/test/ZIPsFS/branch2/
    b4=~/test/ZIPsFS/branch3

    mkdir -p $b1 $b2 $b3 $b4 ~/test/ZIPsFS/mnt

    for c in a b c d e f; do echo hello world $c >$b2/$c.txt; done
    for ((i=0;i<10;i++)); do echo hello world $i >$b3/$i.txt; done

    zip --fifo $b2/zipfile1.zip <(date)  <(echo $RANDOM)
    zip --fifo $b3/zipfile2.zip <(hostname)  <(ls /)
    zip --fifo $b3/20250131_this_is_a_mass_spectrometry_folder.d.Zip   <(seq 10)


### Start ZIPsFS
In production, it is recommended to start ZIPsFS in *tmux*. For testing, just use your regular command line.


    ZIPsFS   $b1 $b2 $b3 $b4  :  ~/test/ZIPsFS/mnt

### Browse the virtual file tree

Open a file browser or another terminal and  browse the files in

    ~/test/ZIPsFS/mnt/

### Create a file in the virtual tree
The first file tree stores files. All others are read-only.

    echo "Hello" > ~/test/ZIPsFS/mnt/my_file.txt

    cat ~/test/ZIPsFS/mnt/my_file.txt

To get the real storage place of the file, append ``@SOURCE.TXT``

    cat ~/test/ZIPsFS/mnt/my_file.txt@SOURCE.TXT

More information is available with suffix ``@PROPRERTIES.TXT``

    cat ~/test/ZIPsFS/mnt/my_file.txt@PROPRERTIES.TXT

### Access web resources as regular files (Not fully tested yet)
Make sure the UNIX tool curl is installed.

    curl --version

Note that "//:" and all slashes in the URL are replaced by commas.

    less  ~/test/ZIPsFS/mnt/zipsfs/n/ftp,,,ftp.uniprot.org,pub,databases,uniprot,LICENSE

    gunzip -c ~/test/ZIPsFS/mnt/zipsfs/n/ftp,,,ftp.ebi.ac.uk,pub,databases,uniprot,current_release,knowledgebase,complete,docs,keywlist.xml.gz


Even though the file is only available in compressed form on the server, you can directly access the decompressed file. Omit  the ``.gz`` extension.

The decompressed file size is an estimate. It becomes exactly known after reading the file.

    head ~/test/ZIPsFS/mnt/zipsfs/n/http,,,ftp.uniprot.org,pub,databases,uniprot,current_release,knowledgebase,reference_proteomes,Eukaryota,UP000005640,UP000005640_9606.fasta
    head ~/test/ZIPsFS/mnt/zipsfs/n/ftp,,,ftp.uniprot.org,pub,databases,uniprot,current_release,knowledgebase,reference_proteomes,Eukaryota,UP000005640,UP000005640_9606.fasta


    ls -l ~/test/ZIPsFS/mnt/zipsfs/n/ftp,,,ftp.ebi.ac.uk,pub,databases,uniprot,current_release,knowledgebase,complete,docs,keywlist.xml

    head ~/test/ZIPsFS/mnt/zipsfs/n/ftp,,,ftp.ebi.ac.uk,pub,databases,uniprot,current_release,knowledgebase,complete,docs,keywlist.xml

From now on, the file size is known.

The gz compression is built-in using the zlib C library. The bz2, xz and lrz
decompression work only if activated in the config (default) and if the respective backends are installed on the
computer. The following are test examples of files remotely stored as bz2 and xz, respectively.

    head ~/test/ZIPsFS/mnt/zipsfs/n/http,,,ftp.gnu.org,gnu,binutils,binutils-2.23.1.tar   # Remote file is .tar.bz2
    head ~/test/ZIPsFS/mnt/zipsfs/n/http,,,ftp.gnu.org,gnu,gawk,gawk-4.0.2.tar            # Remote file is .tar.xz


Above method allows to access any remote file. The disadvantage over the method below is, that repositories are not browsable.










<details><summary>Browsing  public repositories (Pride, Genomes, PDB, Swissprot)</summary>


This requires curl. Please also install  rclone or  curlftpfs (https://curlftpfs.sourceforge.net/).
If using curlftpfs, consider to add timeout like  ``curl_easy_setopt(easy,CURLOPT_TIMEOUT,3600);`` into the ``main()`` function in ``ftpfs.c``.
There is also a similar script for AVFS.


### Browsing FTP sites using nested FUSE file systems

The script file  [ZIPsFS_prepare_branch_for_ftp.sh](./ZIPsFS_prepare_branch_for_ftp.sh) creates folders like ``~/.ZIPsFS/db/pride``
and mounts the respective FTP sites.

Its standard output is used as CLI parameters for the command line of  ZIPsFS.

    ZIPsFS   $b1 $b2 $b3 $b4  $(./ZIPsFS_prepare_branch_for_ftp.sh)   :  ~/test/ZIPsFS/mnt

Now the repositories are available

    ls ~/test/ZIPsFS/mnt/db

GZ compressed files are transparently de-compressed. Files with the ending ``.gz`` also  appear in the file listing without gz suffix.
Initially, they have an estimated file size. After reading the virtual file, the exact length of the
decompressed data is known.

But wait, there is a major problem.  Before decompression, ZIPsFS can only communicate an estimate of the file size of the decompressed file.
Consequently, programs that depend on file sizes will not work initially. Please try


    tail  ~/test/ZIPsFS/mnt/mnt/db/pride/2005/08/PRD000004/PRIDE_Exp_Complete_Ac_369.xml

The first time this command is run, there is no  output. This is because tail sees the wrong file size.
On the second time, tail works as expected.




</details>


# DESCRIPTION



## ZIPsFS is a Union / overlay file system


ZIPsFS functions as a union (overlay) file system.
When files are created or modified, they are stored in the first file tree.
If a file exists in multiple source locations, the version from the leftmost source (the first one listed) takes precedence.
With an empty string as the first source,  the ZIPsFS file system read-only and file creation and modification is disabled.

The physical file path, i.e., the actual storage location of a file, can be retrieved from a
file formed by appending ``@SOURCE.TXT`` to the filename.
For example, to determine the real location of:
    ``~/test/ZIPsFS/mnt/1.txt``
Run the following command:

    cat ~/test/ZIPsFS/mnt/1.txt@SOURCE.TXT

If a remote upstream file system stops responding, the current file access is blocked (Unless the options ``WITH_ASYNC_READDIR`` ... are activated).
After some time, unresponsive upstream file trees will be skipped to prevent that file accesses get blocked.


## ZIPsFS expands ZIP file entries

By default, ZIP files are displayed as folders with the suffix ``.Content``.
This behavior can be customized.
The default configuration includes a few exceptions tailored to specific use cases in Mass Spectrometry:

  - For ZIP files whose names end with *.d.Zip*, the virtual folder will  end with *.d*.

  - Flat file list: For  Sciex instruments, each mass spectrometry record  is stored in a set of files which are not organized in
    sub-folders. For example the record ``20231122_MA_HEK_QC_hiFlow_2ug_SWATH_rep01``  stored in ``20231122_MA_HEK_QC_hiFlow_2ug_SWATH_rep01.wiff2.Zip`` may consist of the following files

     - 20231122_MA_HEK_QC_hiFlow_2ug_SWATH_rep01.timeseries.data
     - 20231122_MA_HEK_QC_hiFlow_2ug_SWATH_rep01.wiff
     - 20231122_MA_HEK_QC_hiFlow_2ug_SWATH_rep01.wiff2
     - 20231122_MA_HEK_QC_hiFlow_2ug_SWATH_rep01.wiff.scan

    These are contained with those of other entries in the file listing.
    To get the full list of files,  all ZIP files need to be inspected.
    This is time consuming and performed in the background. Consequently, the file listing will be incomplete when requested for the first time.
    Only after some seconds, the file listing will be presented properly.

A major advantage of using ZIP archives for storing files is that
Zip files contain a record of the CRC32 checksum of each zip entry. This can be used for integrity checks to detect data decay or problems with data transfer.
This checksum can be obtained from ZIPsFS by appending ``@ARCHIVECRC32.TXT`` to a file path.


## Command line Options


**-h**

Prints brief usage information.



**-s *path-of-symbolic-link**
This is discussed in section Configuration.


**-c \[NEVER,SEEK,RULE,COMPRESSED,ALWAYS\]**

Policy when ZIP entries and file content is cached in RAM.



|           |                                                                                       |
|:---------:|---------------------------------------------------------------------------------------|
|   NEVER   | ZIP entries are never cached, even not in case of backward seek.                      |
|           |                                                                                       |
|   SEEK    | ZIP entries are cached when the file position jumps backward.                         |
|           |                                                                                       |
|   RULE    | ZIP entries are cached according to customizable rules or on backward seed. (DEFAULT) |
|           |                                                                                       |
|COMPRESSED | All compressed ZIP entries are cached.                                                |
|           |                                                                                       |
|  ALWAYS   | All ZIP entries are cached.                                                           |
|           |                                                                                       |

**-l  *Maximum memory for caching ZIP-entries in the RAM***

Specifies a limit for the cache.  For example *-l  8G* would limit the size of the cache to 8 Gigabyte.
File content larger than this will not be cached. When memory usage is high, cached file access waits until it drops below this value.

**-b**
 Execution in background (Not recommended). We recommend running ZIPsFS in foreground in *tmux*.


These rules can be overridden by using the subdirectories ``/zipsfs/-/m/`` and ``/zipsfs/-/-m/``. Please see enclosed README files.


## FUSE command line options


Options for the FUSE system  come after the **colon** in the command line.

**-o *comma separated Options***

**-o allow_other**
Other users are granted access.

The last argument is the mount point which is an empty folder.


## Special directory  <mount-point>``/zipsfs/``

The folder <mount-point>``/zipsfs/`` provides alternative views and file prefetch.
It contains log files and scripts.
The file tree can be accessed in a modified way via

    /zipsfs/<view-option>/<file preload-option>[/<preload-selector>]

### Folder ``/zipsfs/<view-option>/``
The 1st level subdirictory specifies view options. Directives are single letters. They can be combined.
A preceding dash '-' negates.
  - <mount-point>/zipsfs/-     Default view.
  - <mount-point>/zipsfs/z     Rapid navigation and file name searching without time consuming ZIP file expansion.
  - <mount-point>/zipsfs/n     Internet files. Take URL and replace colon and slashes by comma. See above tutorial.
  - <mount-point>/zipsfs/d     For bz2, xz, gz, .Z and lrz compressed files also generate the decompressed file.
  - <mount-point>/zipsfs/1    Files of the first branch only. This includes all files ever written or generated or modified.
  - <mount-point>/zipsfs/~1   Files except from first branch.
  - <mount-point>/zipsfs/c    Show convert files along the original files. Example:
        - Raw mass spectrometry to mgf or mzML files or tsv
        - Parquet to tsv
  - <mount-point>/zipsfs/log   Logging, to identify very busy software which should rather be used with preloading of remote or compressed files.
       - Excessive requests of file attributes
       - Multiple open/close
       - Backward seek
       - Upper/lower case conversion of file names


Details are found in the contained readme files.

### /zipsfs/<view-option>/<prefetch option>
The follwing path component may instruct preloading of files. Files are preloaded just before the first byte is read.
  - /-/ Apply  default preload rules defined in ``ZIPsFS_configuration.c`` and ``ZIPsFS_configuration.h`` and specified by root properties.
  - /m/ Prefetch to RAM
  - /-m/ Do not prefetch to RAM
  - /l/ Prefetch to the local file system
  - /-l/ Do not prefetch to the local file system

The /m/ and /l/ folder have a subfolder with selectors: (a) all, (r) remote and (z) ZIP-entry.


## Properties of upstream file trees

In the command line, root file paths  can be followed by expressions like @immutable=1 to set specific properties.
Alternatively, properties can be written in a file ``<root-path>.ZIPsFS.properties``. This is demonstrated in   [ZIPsFS_prepare_branch_for_ftp.sh](ZIPsFS_prepare_branch_for_ftp.sh).

For a  list of properties  run

    ZIPsFS -h

<details><summary>Preload files</summary>


Non-linear file loading in a random-access manner is inefficient for remote or ZIP-compressed files.
This is the case for the MS-programs Diann and FragPipe (Fragger).

## File content pre-load

Remote or compressed files can be preloaded in two different ways: (I) into RAM or (II) to the local disk.

### Preloading into RAM

File names to be cached in RAM  are specified in the configurable method ``config_advise_cache_in_ram()``.  The default
setting includes Brukertimstof mass-spectrometry files. Preloading to the RAM is appropriate for these files because
each file is loaded only once per analysis. It is necessary because these mass-spectrometry files are loaded from varying file positions which would be inefficient for
remote or compressed files.
The ``-l`` option sets an upper limit on memory usage
for the ZIP RAM cache.  When available memory runs low, ZIPsFS can either pause, proceed without
caching file data or just ignore the memory restriction depending on the configuration.

### Preloading to local disk

File reading of remote or compressed files can be improved by caching the file content on the local disk.
This is for example necessary for Thermo  mass-spectrometry raw files analyzed in FragPipe.
Above method of preloading into RAM is here  inappropriate because each raw file is
opened and closed multiple times during computation such that the large files would be transfered from the NAS several times.

All remote (r) or compressed (c) or zippded (z) files
accessed through the following folders will be first copied to local disk:

    <mount-point>/zipsfs/-/l/r/
    <mount-point>/zipsfs/-/l/z/
    <mount-point>/zipsfs/-/l/rz/

The Readme in these folders provide further information.
Alternatively, the entire root-path can be marked for preloading with the property ``@preload``.

### Decompression

Decompression is enabled with properties like ``@preload=1`` of for specific compression suffixes like  ``@preload=gz,xz``.
Irrespectively of root attributes, decompression is  active for the file tree

    <mount-point>/zipsfs/d/


</details>


<details><summary>Project status</summary>

Author: Christoph Gille

**Current status**: Testing and Bug fixing. Already running very busy for several weeks without interruption.


If ZIPsFS crashes, please send the stack-trace together with the source code you were using.

</details>



## End ZIPsFS

ZIPsFS can be killed like any UNIX command by typing  Ctrl-C.
Sometimes this does not work. Assuming mnt is your mount-point, the following might work:

    fusermount -u mnt
    sudo umount mnt

If ZIPsFS still hangs, the following will kill all FUSE file systems of the current user.
Those of other users won't be affected:

    echo 1 | sudo tee /sys/fs/fuse/connections/*/abort


## Changelog

- 202601
   - Changing ZIPsFS to lower-case in <mount-point>/zipsfs. This was necessary to export  ZIPsFS as a Samba Share to Windows
- 202610
   - Re-organized the <mount-point>/zipsfs file branch.
   - Solved problem of file truncation due to underestimated file size
