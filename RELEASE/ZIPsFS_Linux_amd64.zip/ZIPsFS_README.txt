Please install libzip and libfuse3
On Debian/Ubuntu run as root:

 apt-get install libzip libfuse3
